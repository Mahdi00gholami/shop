export default function Home() {
  return (
    <section className="mx-auto max-w-5xl p-8">
      <h1 className="text-3xl font-bold text-blue-700">Welcome to Simple Shop</h1>
      <p className="mt-4">A simple React shopping project built with components, JSX, props and state.</p>
    </section>
  );
}

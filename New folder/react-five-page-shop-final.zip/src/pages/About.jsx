export default function About() {
  return (
    <section className="mx-auto max-w-5xl p-8">
      <h1 className="text-3xl font-bold">About</h1>
      <p className="mt-4">This project uses the React course patterns for components, JSX, props, events, controlled forms and shopping basket state.</p>
    </section>
  );
}
